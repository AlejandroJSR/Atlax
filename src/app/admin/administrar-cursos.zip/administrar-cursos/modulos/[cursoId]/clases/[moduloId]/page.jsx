"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { collection, getDocs, deleteDoc, doc, setDoc } from "firebase/firestore";
import { db } from "@/services/firebase";
import ClaseEditor from "@/components/ClaseEditor";

export default function ClasesPage() {
  const { cursoId, moduloId } = useParams();
  const router = useRouter();
  const [clases, setClases] = useState([]);
  const [editing, setEditing] = useState(null);
  const [isNew, setIsNew] = useState(false);

  const fetchClases = async () => {
    const snapshot = await getDocs(
      collection(db, `cursos/${cursoId}/modulos/${moduloId}/clases`)
    );
    setClases(snapshot.docs.map((d) => ({ id: d.id, ...d.data() })));
  };

  useEffect(() => {
    fetchClases();
  }, []);

  const handleDelete = async (id) => {
    if (confirm("¿Eliminar esta clase?")) {
      await deleteDoc(doc(db, `cursos/${cursoId}/modulos/${moduloId}/clases/${id}`));
      fetchClases();
    }
  };

  const handleNew = () => {
    // No crear documento aún, solo abrir editor vacío
    setEditing({ titulo: "", contenido: "" });
    setIsNew(true);
  };

  const handleSaveNew = async (data) => {
    const newRef = doc(collection(db, `cursos/${cursoId}/modulos/${moduloId}/clases`));
    await setDoc(newRef, {
      ...data,
      fechaCreacion: new Date(),
    });
    setEditing(null);
    setIsNew(false);
    fetchClases();
  };

  const handleUpdate = async (id, data) => {
    await setDoc(
      doc(db, `cursos/${cursoId}/modulos/${moduloId}/clases/${id}`),
      { ...data, fechaActualizacion: new Date() },
      { merge: true }
    );
    setEditing(null);
    setIsNew(false);
    fetchClases();
  };

  const handleBack = () => {
    setEditing(null);
    setIsNew(false);
  };

  if (editing) {
    return (
      <ClaseEditor
        cursoId={cursoId}
        moduloId={moduloId}
        claseId={isNew ? null : editing.id}
        initialData={editing}
        onBack={handleBack}
        onSave={(data) =>
          isNew ? handleSaveNew(data) : handleUpdate(editing.id, data)
        }
        onDelete={
          isNew
            ? null
            : async () => {
                await handleDelete(editing.id);
                handleBack();
              }
        }
      />
    );
  }

  return (
    <div>
      <h2 className="mb-6 text-xl font-bold text-[#2d249c]">Clases del módulo</h2>
      <button
        onClick={() => router.back()}
        className="mb-4 bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
      >
        ← Volver
      </button>
      <button
        onClick={handleNew}
        className="mb-4 ml-2 bg-[#2d249c] text-white px-4 py-2 rounded hover:bg-[#241d74]"
      >
        Crear Clase
      </button>

      {clases.length === 0 ? (
        <p className="text-gray-900">No hay clases creadas</p>
      ) : (
        <div className="w-full bg-white rounded-xl shadow-lg mb-4 overflow-x-auto max-w-full">
          <table className="w-full text-xs md:text-sm text-left">
            <thead>
              <tr className="bg-violet-100 text-gray-900">
                <th className="px-2 py-2 font-bold">Título</th>
                <th className="px-2 py-2 font-bold">Acciones</th>
              </tr>
            </thead>
            <tbody>
              {clases.map((clase) => (
                <tr key={clase.id} className="border-b hover:bg-gray-50">
                  <td className="px-2 py-2 text-gray-900">{clase.titulo}</td>
                  <td className="px-2 py-2 flex gap-2">
                    <button
                      onClick={() => {
                        setEditing(clase);
                        setIsNew(false);
                      }}
                      className="bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1 rounded"
                    >
                      Editar
                    </button>
                    <button
                      onClick={() => handleDelete(clase.id)}
                      className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded"
                    >
                      Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
